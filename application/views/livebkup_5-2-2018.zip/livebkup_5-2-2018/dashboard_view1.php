<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">
    <script type="text/javascript">
        var chartData = [['Month', 'Enquiry', 'Booking']];
<?php
foreach ($getEnquiryChartDataByMonth as $getEnquiryChartData) {
    ?>
            chartData.push(['<?php echo $getEnquiryChartData['enqStrMonth'] . '-' . $getEnquiryChartData['enqYear']; ?>', <?php echo $getEnquiryChartData['enquiryCnt']; ?>, <?php echo $getEnquiryChartData['bookingCnt']; ?>]);
    <?php
}
?>

    </script>
    <div class="page-wrapper">
        <!-- BEGIN HEADER -->
        <?php include "template/leftmenu.php"; ?>
        <!-- END HEADER -->

        <!-- BEGIN CONTENT -->
        <div class="page-content-wrapper">
            <!-- BEGIN CONTENT BODY -->
            <div class="page-content" style="margin-left: 0">
                <!-- BEGIN PAGE HEADER-->
                <!-- BEGIN PAGE BAR -->
                <div class="page-bar">
                    <!--<ul class="page-breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                            <i class="fa fa-circle"></i>
                        </li>
                        <li>
                            <span>Dashboard</span>
                        </li>
                    </ul>-->
                </div>
                <!-- END PAGE BAR -->
                <!-- BEGIN PAGE TITLE-->
                <h1 class="page-title"> 
                    <small></small>
                </h1>
                <!-- END PAGE TITLE-->
                <!-- END PAGE HEADER-->
                <!-- BEGIN DASHBOARD STATS 1-->
                <div class="row">
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                        <a class="dashboard-stat dashboard-stat-v2 red" href="#">
                            <div class="visual">
                                <i class="fa fa-newspaper-o"></i>
                            </div>
                            <div class="details">
                                <div class="number">
                                    <span data-counter="counterup" class="todayCountBook" data-value="<?php echo $todayNewBooking; ?>">0</span></div>
                                <div class="desc"> Today's Bookings </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                        <a class="dashboard-stat dashboard-stat-v2 red" href="#">
                            <div class="visual">
                                <i class="fa fa-newspaper-o"></i>
                            </div>
                            <div class="details">
                                <div class="number">
                                    <span data-counter="counterup" class="yestCountBook" data-value="<?php echo $yesterDayNewBooking; ?>">0</span>
                                </div>
                                <div class="desc"> Yesterday's Bookings </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                        <a class="dashboard-stat dashboard-stat-v2 blue" href="#">
                            <div class="visual">
                                <i class="fa fa-pencil-square-o"></i>
                            </div>
                            <div class="details">
                                <div class="number">
                                    <span data-counter="counterup" class="todayCountEnq" data-value="<?php echo $todayNewEnquiry; ?>">0</span></div>
                                <div class="desc"> Today's Enquiries </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                        <a class="dashboard-stat dashboard-stat-v2 blue" href="#">
                            <div class="visual">
                                <i class="fa fa-pencil-square-o"></i>
                            </div>
                            <div class="details">
                                <div class="number">
                                    <span data-counter="counterup" class="yestCountEnq" data-value="<?php echo $yesterDayNewEnquiry; ?>"><?php echo $yesterDayNewEnquiry; ?></span>
                                </div>
                                <div class="desc"> Yesterday's Enquiries </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                        <a class="dashboard-stat dashboard-stat-v2 green" href="#">
                            <div class="visual">
                                <i class="fa fa-newspaper-o"></i>
                            </div>
                            <div class="details">
                                <div class="number">
                                    <span data-counter="counterup" class="tomorrowCountBook" data-value="<?php echo $tomorrowNewBooking; ?>">0</span></div>
                                <div class="desc"> Tomorrow's Bookings </div>
                            </div>
                        </a>
                    </div>




                </div>
                <div class="clearfix"></div>
                <!-- END DASHBOARD STATS 1-->
                <div class="row">
                    <div class="col-lg-12 col-xs-12 col-sm-12">
                        <!-- BEGIN PORTLET-->
                        <div class="portlet light bordered">
                            <div class="portlet-title">
                                <div class="caption">
                                    <i class="icon-share font-red-sunglo hide"></i>
                                    <span class="caption-subject font-dark bold uppercase">Monthly Summary</span>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div id="columnchart_material" style="width: 100%; height: 500px;"></div>
                            </div>
                        </div>
                        <!-- END PORTLET-->
                    </div>

                </div>
            </div>
            <!-- END CONTENT BODY -->
        </div>
        <!-- END CONTENT -->
    </div>
    <!-- END CONTAINER -->
</div>


<div class="quick-nav-overlay"></div>
